def verify_skill_numeric_gates(metrics: dict) -> bool:
    return (
        metrics.get("niagara_gpu_particles_max", 0) <= 65536
        and metrics.get("chaos_solver_iterations", 0) >= 8
        and metrics.get("metasounds_sample_rate_hz", 0) == 48000
        and metrics.get("commonui_input_latency_ms", 99) == 0
    )
