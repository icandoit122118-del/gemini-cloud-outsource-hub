---
name: ue59-official-core-subsystems
description: 언리얼 엔진 5.9 공식 문서 기반 나이아가라·카오스·메타사운드·커먼UI 표준 스킬
ue_version: "5.9"
license: MIT
---

# 언리얼 5.9 4대 핵심 서브시스템 공식 표준 스킬

## 1. Niagara (나이아가라 파티클 시스템)
- GPU 시뮬레이션 파티클 상한 및 고정 바운드(`FixedBounds`) 필수 설정

## 2. Chaos (카오스 물리 및 파괴)
- 솔버 위치 반복 횟수 및 침투 보정 속도 상한 준수

## 3. MetaSounds (메타사운드 절차적 오디오)
- 48000Hz 표준 샘플레이트 및 동시 활성 보이스 예산 준수

## 4. CommonUI (커먼UI 계층형 입력 라우팅)
- 입력 라우팅 지연 0ms 및 포커스 스택 깊이 상한 검증
